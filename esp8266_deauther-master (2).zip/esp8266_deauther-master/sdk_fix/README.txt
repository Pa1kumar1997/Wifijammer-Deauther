Copy and replace the files at these locations:

user_interface.h -> \packages\esp8266\hardware\esp8266\2.0.0\tools\sdk\include
ESP8266WiFi.cpp and ESP8266WiFi.h -> \packages\esp8266\hardware\esp8266\2.0.0\libraries\ESP8266WiFi\src